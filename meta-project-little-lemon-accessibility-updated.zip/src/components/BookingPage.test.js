import "@testing-library/jest-dom";
import React from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { initializeTimes, updateTimes } from "./BookingPage";
import BookingPage from "./BookingPage";

const getTodayForTest = () => {
  const today = new Date();
  const year = today.getFullYear();
  const month = String(today.getMonth() + 1).padStart(2, "0");
  const day = String(today.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
};

const availableTimes = ["17:00", "18:30", "20:00"];

const renderBookingPage = (submitForm = jest.fn(() => true)) => {
  window.fetchAPI = jest.fn(() => availableTimes);
  render(<BookingPage submitForm={submitForm} />);
  return submitForm;
};

describe("Booking API queries", () => {
  const originalFetchAPI = window.fetchAPI;

  beforeEach(() => {
    window.fetchAPI = jest.fn(() => availableTimes);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  afterAll(() => {
    if (originalFetchAPI) {
      window.fetchAPI = originalFetchAPI;
    } else {
      delete window.fetchAPI;
    }
  });

  test("initializeTimes returns a non-empty array of available booking times", () => {
    const result = initializeTimes();

    expect(Array.isArray(result)).toBe(true);
    expect(result.length).toBeGreaterThan(0);
    expect(window.fetchAPI).toHaveBeenCalledTimes(1);
    expect(window.fetchAPI.mock.calls[0][0]).toBeInstanceOf(Date);
  });

  test("updateTimes returns available booking times for the selected date", () => {
    const selectedDate = "2026-10-15";
    const result = updateTimes([], { date: selectedDate });

    expect(Array.isArray(result)).toBe(true);
    expect(result.length).toBeGreaterThan(0);
    expect(window.fetchAPI).toHaveBeenCalledTimes(1);
    expect(window.fetchAPI).toHaveBeenCalledWith(
      new Date(`${selectedDate}T00:00:00`)
    );
  });
});

describe("Booking form HTML5 validation", () => {
  beforeEach(() => {
    window.fetchAPI = jest.fn(() => availableTimes);
  });

  test("applies required and text validation attributes to first name", () => {
    render(<BookingPage submitForm={jest.fn(() => true)} />);
    const firstName = screen.getByRole("textbox", { name: "Name" });

    expect(firstName).toHaveAttribute("name", "firstName");
    expect(firstName).toHaveAttribute("type", "text");
    expect(firstName).toBeRequired();
  });

  test("applies required and text validation attributes to last name", () => {
    render(<BookingPage submitForm={jest.fn(() => true)} />);
    const lastName = screen.getByRole("textbox", { name: "Last Name" });

    expect(lastName).toHaveAttribute("name", "lastName");
    expect(lastName).toHaveAttribute("type", "text");
    expect(lastName).toBeRequired();
  });

  test("applies required and minimum-date validation to date", () => {
    render(<BookingPage submitForm={jest.fn(() => true)} />);
    const date = screen.getByLabelText("Reservation date");

    expect(date).toHaveAttribute("name", "date");
    expect(date).toHaveAttribute("type", "date");
    expect(date).toBeRequired();
    expect(date).toHaveAttribute("min", getTodayForTest());
  });

  test("applies required validation and renders available booking times", () => {
    render(<BookingPage submitForm={jest.fn(() => true)} />);
    const time = screen.getByLabelText("Reservation time");

    expect(time).toHaveAttribute("name", "time");
    expect(time).toBeRequired();
    availableTimes.forEach((bookingTime) => {
      expect(screen.getByRole("option", { name: bookingTime })).toBeInTheDocument();
    });
  });

  test("applies required, minimum, and maximum validation to guest count", () => {
    render(<BookingPage submitForm={jest.fn(() => true)} />);
    const guests = screen.getByRole("spinbutton", { name: "Number of Guest" });

    expect(guests).toHaveAttribute("name", "guests");
    expect(guests).toHaveAttribute("type", "number");
    expect(guests).toBeRequired();
    expect(guests).toHaveAttribute("min", "1");
    expect(guests).toHaveAttribute("max", "10");
  });

  test("applies required validation to occasion", () => {
    render(<BookingPage submitForm={jest.fn(() => true)} />);
    const occasion = screen.getByRole("combobox", { name: "Occasion" });

    expect(occasion).toHaveAttribute("name", "occasion");
    expect(occasion).toBeRequired();
  });

  test("associates every reservation label with its form control", () => {
    render(<BookingPage submitForm={jest.fn(() => true)} />);

    const expectedLabels = [
      ["Name", "firstName"],
      ["Last Name", "lastName"],
      ["Date", "date"],
      ["Time", "time"],
      ["Number of Guest", "guests"],
      ["Occasion", "occasion"],
    ];

    expectedLabels.forEach(([label, id]) => {
      const control = screen.getByLabelText(label);
      expect(control).toHaveAttribute("id", id);
      expect(document.querySelector(`label[for="${id}"]`)).toBeInTheDocument();
    });
  });
});

describe("Booking form React validation", () => {
  beforeEach(() => {
    window.fetchAPI = jest.fn(() => availableTimes);
  });

  test("keeps submission disabled when first name is empty", () => {
    renderBookingPage();
    const firstName = screen.getByRole("textbox", { name: "Name" });
    const submitButton = screen.getByRole("button", { name: "Reserve a Table" });

    fireEvent.change(firstName, { target: { value: "" } });

    expect(submitButton).toBeDisabled();
  });

  test("keeps submission disabled when last name is empty", () => {
    renderBookingPage();
    const lastName = screen.getByRole("textbox", { name: "Last Name" });
    const submitButton = screen.getByRole("button", { name: "Reserve a Table" });

    fireEvent.change(lastName, { target: { value: "" } });

    expect(submitButton).toBeDisabled();
  });

  test("keeps submission disabled when the date is empty", () => {
    renderBookingPage();
    const date = screen.getByLabelText("Reservation date");
    const submitButton = screen.getByRole("button", { name: "Reserve a Table" });

    fireEvent.change(date, { target: { value: "" } });

    expect(submitButton).toBeDisabled();
  });

  test("keeps submission disabled when the date is earlier than today", () => {
    renderBookingPage();
    const date = screen.getByLabelText("Reservation date");
    const submitButton = screen.getByRole("button", { name: "Reserve a Table" });

    fireEvent.change(date, { target: { value: "2020-01-01" } });

    expect(submitButton).toBeDisabled();
  });

  test("keeps submission disabled until an available time is selected", () => {
    renderBookingPage();
    const time = screen.getByLabelText("Reservation time");
    const submitButton = screen.getByRole("button", { name: "Reserve a Table" });

    expect(time).toHaveValue("");
    expect(submitButton).toBeDisabled();

    fireEvent.change(time, { target: { value: "19:00" } });

    expect(submitButton).toBeDisabled();
  });

  test("keeps submission disabled when guest count is below one", () => {
    renderBookingPage();
    const guests = screen.getByRole("spinbutton", { name: "Number of Guest" });
    const submitButton = screen.getByRole("button", { name: "Reserve a Table" });

    fireEvent.change(guests, { target: { value: "0" } });

    expect(submitButton).toBeDisabled();
  });

  test("keeps submission disabled when guest count is above ten", () => {
    renderBookingPage();
    const guests = screen.getByRole("spinbutton", { name: "Number of Guest" });
    const submitButton = screen.getByRole("button", { name: "Reserve a Table" });

    fireEvent.change(guests, { target: { value: "11" } });

    expect(submitButton).toBeDisabled();
  });

  test("keeps submission disabled when occasion is empty", () => {
    renderBookingPage();
    const occasion = screen.getByRole("combobox", { name: "Occasion" });
    const submitButton = screen.getByRole("button", { name: "Reserve a Table" });

    fireEvent.change(occasion, { target: { value: "" } });

    expect(submitButton).toBeDisabled();
  });

  test("enables submission for a complete valid reservation and calls submitForm", () => {
    const submitForm = renderBookingPage();
    const firstName = screen.getByRole("textbox", { name: "Name" });
    const lastName = screen.getByRole("textbox", { name: "Last Name" });
    const date = screen.getByLabelText("Reservation date");
    const time = screen.getByLabelText("Reservation time");
    const guests = screen.getByRole("spinbutton", { name: "Number of Guest" });
    const occasion = screen.getByRole("combobox", { name: "Occasion" });
    const submitButton = screen.getByRole("button", { name: "Reserve a Table" });

    userEvent.type(firstName, "John");
    userEvent.type(lastName, "Doe");
    fireEvent.change(date, { target: { value: getTodayForTest() } });
    userEvent.selectOptions(time, "18:30");
    fireEvent.change(guests, { target: { value: "4" } });
    userEvent.selectOptions(occasion, "Anniversary");

    expect(submitButton).toBeEnabled();

    userEvent.click(submitButton);

    expect(submitForm).toHaveBeenCalledTimes(1);
    expect(submitForm.mock.calls[0][0]).toBeInstanceOf(FormData);
  });

  test("does not call submitForm when invalid data is submitted", () => {
    const submitForm = renderBookingPage();
    const submitButton = screen.getByRole("button", { name: "Reserve a Table" });

    expect(submitButton).toBeDisabled();

    fireEvent.submit(subscreenForm());

    expect(submitForm).not.toHaveBeenCalled();
  });
});

function subscreenForm() {
  return screen.getByRole("button", { name: "Reserve a Table" }).closest("form");
}
