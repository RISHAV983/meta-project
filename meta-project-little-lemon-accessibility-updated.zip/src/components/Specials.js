import { Link } from "react-router-dom";

const specials = [
  {
    image: "https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=900&q=85",
    name: "Greek salad",
    price: "$12.00",
    description: "The famous greek salad of crispy lettuce, peppers, olives and our Chicago style feta cheese, garnished with crunchy garlic and rosemary croutons.",
  },
  {
    image: "https://images.unsplash.com/photo-1572695157366-5e585ab2b69f?auto=format&fit=crop&w=900&q=85",
    name: "Bruschetta",
    price: "$12.00",
    description: "Our Bruschetta is made from grilled bread that has been smeared with garlic and seasoned with salt and olive oil.",
  },
  {
    image: "https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?auto=format&fit=crop&w=900&q=85",
    name: "Lemon dessert",
    price: "$12.00",
    description: "This comes straight from grandma's recipe book, every last ingredient has been sourced and is as authentic as can be imagined.",
  },
];

function Specials() {
  return (
    <section id="specials" className="specials-section">
      <div className="site-container">
        <h2 className="section-title">This Weeks Specials!</h2>
        <div className="specials-grid">
          {specials.map((item) => (
            <article className="special-card" key={item.name}>
              <img src={item.image} alt={item.name} />
              <div className="special-content">
                <div className="special-heading">
                  <h3>{item.name}</h3>
                  <span>{item.price}</span>
                </div>
                <p>{item.description}</p>
                <Link className="delivery-button" to="/booking">Order a delivery <span aria-hidden="true">⌁</span></Link>
              </div>
            </article>
          ))}
        </div>
        <Link className="primary-button explore-button" to="/#specials">Explore Menu</Link>
      </div>
    </section>
  );
}

export default Specials;
