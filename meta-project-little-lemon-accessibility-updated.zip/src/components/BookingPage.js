import { useReducer, useState } from "react";

const initialForm = {
  firstName: "",
  lastName: "",
  date: "",
  time: "",
  guests: "4",
  occasion: "Birthday",
};

const getToday = () => {
  const today = new Date();
  const year = today.getFullYear();
  const month = String(today.getMonth() + 1).padStart(2, "0");
  const day = String(today.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
};

const toDateObject = (dateValue) => {
  if (dateValue instanceof Date) {
    return dateValue;
  }

  if (!dateValue) {
    return new Date();
  }

  return new Date(`${dateValue}T00:00:00`);
};

const fetchAvailableTimes = (date) => {
  if (typeof window !== "undefined" && typeof window.fetchAPI === "function") {
    return window.fetchAPI(toDateObject(date));
  }

  return [];
};

// Used by the booking-time reducer to load today's available times initially.
export const initializeTimes = () => fetchAvailableTimes(new Date());

// Used by the booking-time reducer whenever the selected date changes.
export const updateTimes = (state, action) => {
  if (!action || !action.date) {
    return state;
  }

  return fetchAvailableTimes(action.date);
};

function BookingPage({ submitForm }) {
  const [form, setForm] = useState({ ...initialForm, date: getToday() });
  const [availableTimes, dispatch] = useReducer(
    updateTimes,
    undefined,
    initializeTimes
  );
  const [message, setMessage] = useState("");

  const handleChange = (event) => {
    const { name, value } = event.target;
    setForm((current) => ({ ...current, [name]: value }));
    setMessage("");

    if (name === "date") {
      dispatch({ date: value });
    }
  };

  const isFormValid =
    form.firstName.trim() !== "" &&
    form.lastName.trim() !== "" &&
    form.date !== "" &&
    form.date >= getToday() &&
    form.time !== "" &&
    availableTimes.includes(form.time) &&
    Number(form.guests) >= 1 &&
    Number(form.guests) <= 10 &&
    form.occasion !== "";

  const handleSubmit = (event) => {
    event.preventDefault();

    if (!event.currentTarget.checkValidity() || !isFormValid) {
      event.currentTarget.reportValidity();
      setMessage("Please complete the form with valid information.");
      return;
    }

    const formData = new FormData(event.currentTarget);
    const submitted = submitForm(formData);

    if (!submitted) {
      setMessage("We could not submit your reservation. Please try again.");
    }
  };

  return (
    <section id="reservation" className="reservation-section">
      <div className="reservation-overlay" />
      <div className="site-container reservation-inner">
        <h2>Reserve Your Table</h2>
        <p>Book a table in advance to enjoy your time with Friends and Family</p>
        <form className="reservation-form" onSubmit={handleSubmit}>
          <label htmlFor="firstName">
            <span>Name</span>
            <input
              id="firstName"
              name="firstName"
              type="text"
              value={form.firstName}
              onChange={handleChange}
              placeholder="John"
              required
            />
          </label>
          <label htmlFor="lastName">
            <span>Last Name</span>
            <input
              id="lastName"
              name="lastName"
              type="text"
              value={form.lastName}
              onChange={handleChange}
              placeholder="Doe"
              required
            />
          </label>
          <label htmlFor="date">
            <span>Date</span>
            <input
              id="date"
              type="date"
              name="date"
              value={form.date}
              min={getToday()}
              onChange={handleChange}
              aria-label="Reservation date"
              required
            />
          </label>
          <label htmlFor="time">
            <span>Time</span>
            <select id="time" name="time" value={form.time} onChange={handleChange} aria-label="Reservation time" required>
              <option value="">Select a time</option>
              {availableTimes.map((time) => (
                <option key={time} value={time}>
                  {time}
                </option>
              ))}
            </select>
          </label>
          <label htmlFor="guests">
            <span>Number of Guest</span>
            <input
              id="guests"
              type="number"
              name="guests"
              min="1"
              max="10"
              value={form.guests}
              onChange={handleChange}
              required
            />
          </label>
          <label htmlFor="occasion">
            <span>Occasion</span>
            <select id="occasion" name="occasion" value={form.occasion} onChange={handleChange} required>
              <option>Birthday</option>
              <option>Anniversary</option>
              <option>Date Night</option>
              <option>Business</option>
              <option>Other</option>
            </select>
          </label>
          <button
            className="primary-button reservation-submit"
            type="submit"
            disabled={!isFormValid}
          >
            Reserve a Table
          </button>
        </form>
        {message && <p className="form-message" role="status">{message}</p>}
      </div>
    </section>
  );
}

export default BookingPage;
