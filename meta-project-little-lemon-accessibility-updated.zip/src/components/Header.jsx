import { useState } from "react";
import { Link } from "react-router-dom";
import Nav from "./Nav";

function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  const closeMenu = () => setMenuOpen(false);

  return (
    <header className="site-header">
      <div className="site-container header-inner">
        <Link className="brand" to="/" onClick={closeMenu} aria-label="Little Lemon home">
          <img src="/little-lemon-logo.svg" alt="Little Lemon" className="brand-logo" />
        </Link>

        <button
          className="menu-toggle"
          type="button"
          aria-label="On Click"
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen((open) => !open)}
        >
          <span />
          <span />
          <span />
        </button>

        <nav className={`site-nav ${menuOpen ? "is-open" : ""}`} aria-label="Primary navigation">
          <Nav closeMenu={closeMenu} />
        </nav>
      </div>
    </header>
  );
}

export default Header;
