import { Route, Routes, useNavigate } from "react-router-dom";
import HomePage from "./HomePage";
import BookingPage from "./BookingPage";
import ConfirmedBooking from "./ConfirmedBooking";

function Main() {
  const navigate = useNavigate();

  const submitForm = (formData) => {
    const submitted =
      typeof window !== "undefined" && typeof window.submitAPI === "function"
        ? window.submitAPI(formData)
        : false;

    if (submitted) {
      navigate("/confirmed");
    }

    return submitted;
  };

  return (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route
        path="/booking"
        element={<BookingPage submitForm={submitForm} />}
      />
      <Route path="/confirmed" element={<ConfirmedBooking />} />
    </Routes>
  );
}

export default Main;
