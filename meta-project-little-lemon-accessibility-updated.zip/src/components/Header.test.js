import "@testing-library/jest-dom";
import React from "react";
import { render, screen } from "@testing-library/react";
import { BrowserRouter } from "react-router-dom";
import Header from "./Header";

describe("Header accessibility", () => {
  test("exposes navigation as a landmark and includes the required On Click ARIA label", () => {
    render(
      <BrowserRouter>
        <Header />
      </BrowserRouter>
    );

    expect(screen.getByRole("navigation", { name: "Primary navigation" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "On Click" })).toHaveAttribute(
      "aria-label",
      "On Click"
    );
  });
});
