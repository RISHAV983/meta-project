import { Link } from "react-router-dom";

function Nav({ closeMenu }) {
  return (
    <ul>
      <li><Link to="/" onClick={closeMenu}>Home</Link></li>
      <li><Link to="/#about" onClick={closeMenu}>About</Link></li>
      <li><Link to="/#specials" onClick={closeMenu}>Menu</Link></li>
      <li><Link to="/booking" onClick={closeMenu}>Reservation</Link></li>
      <li><Link to="/#specials" onClick={closeMenu}>Order Online</Link></li>
      <li><Link className="login-button" to="/#login" onClick={closeMenu}>Login</Link></li>
    </ul>
  );
}

export default Nav;
