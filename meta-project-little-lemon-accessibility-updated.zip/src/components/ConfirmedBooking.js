function ConfirmedBooking() {
  return (
    <section className="confirmation-section" aria-labelledby="confirmed-booking-title">
      <div className="site-container confirmation-inner">
        <h1 id="confirmed-booking-title">Booking Confirmed!</h1>
        <p>Your table has been successfully reserved. We look forward to welcoming you to Little Lemon.</p>
      </div>
    </section>
  );
}

export default ConfirmedBooking;
