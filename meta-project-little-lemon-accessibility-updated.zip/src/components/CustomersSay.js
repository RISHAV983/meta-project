const testimonials = [
  {
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=160&q=80",
    food: "https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=180&q=80",
    name: "Ronald Richards",
    location: "Bridgeport",
    rating: 5,
  },
  {
    image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=160&q=80",
    food: "https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=180&q=80",
    name: "Ronald Richards",
    location: "Jefferson Park",
    rating: 4,
  },
  {
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=160&q=80",
    food: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=180&q=80",
    name: "Ronald Richards",
    location: "Lincoln Square",
    rating: 4,
  },
];

function CustomersSay() {
  return (
    <section className="testimonials-section">
      <div className="site-container">
        <h2 className="section-title">What do our customers think?</h2>
        <div className="testimonials-grid">
          {testimonials.map((customer, index) => (
            <article className="testimonial-card" key={`${customer.location}-${index}`}>
              <div className="customer-info">
                <img src={customer.image} alt="" />
                <div>
                  <h3>{customer.name}</h3>
                  <p>debra.holt@example.com</p>
                  <span>{customer.location}</span>
                </div>
              </div>
              <p className="testimonial-copy">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
              <div className="rating-row">
                <img src={customer.food} alt="Dish" />
                <span aria-label={`${customer.rating} out of 5 stars`} className="stars">{"★".repeat(customer.rating)}{"☆".repeat(5 - customer.rating)}</span>
              </div>
            </article>
          ))}
        </div>
        <div className="carousel-controls" aria-hidden="true"><span>‹</span><span>›</span></div>
      </div>
    </section>
  );
}

export default CustomersSay;
