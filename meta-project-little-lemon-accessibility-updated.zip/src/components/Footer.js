import { Link } from "react-router-dom";

function Footer() {
  return (
    <footer id="login" className="site-footer">
      <div className="site-container footer-grid">
        <div className="footer-brand">
          <img className="footer-logo" src="/footer-logo.svg" alt="Little Lemon" />
        </div>
        <nav aria-label="Footer navigation">
          <h3>Navigation</h3>
          <Link to="/">Home</Link><Link to="/#about">About</Link><Link to="/#specials">Menu</Link><Link to="/booking">Reservations</Link><Link to="/#specials">Order Online</Link><Link to="/#login">Login</Link>
        </nav>
        <section aria-labelledby="footer-contact-heading">
          <h3 id="footer-contact-heading">Contact</h3>
          <p>69 Vicon Araratiano</p><p>(709) 879-4459</p><p>Email Us</p>
        </section>
        <section aria-labelledby="footer-socials-heading">
          <h3 id="footer-socials-heading">Socials</h3>
          <Link to="/#login">Facebook</Link><Link to="/#login">Twitter</Link><Link to="/#login">Instagram</Link>
        </section>
      </div>
      <div className="site-container footer-bottom"><span>2026 © Little Lemon</span><span className="social-icons">●　◎　♥　▶　ℙ</span></div>
    </footer>
  );
}

export default Footer;
