# Little Lemon Meta Front-End Capstone

This project uses the existing Meta Capstone React structure and dependencies. The homepage layout has been integrated from the supplied Little Lemon Figma design reference using reusable React components, CSS Grid, Flexbox, and responsive media queries.

## Run locally

```bash
npm install
npm start
```

Open http://localhost:3000.

## Production build

```bash
npm run build
```

## Main components

- `Header.jsx` — responsive navigation and mobile menu
- `CallToAction.js` — hero section
- `BookingPage.js` — reservation form and validation
- `Specials.js` — weekly specials grid
- `CustomersSay.js` — testimonials
- `Chicago.js` — restaurant description and gallery
- `Footer.js` — footer/navigation/contact area
- `App.css` — responsive Grid/Flexbox layout and visual styling

No new npm dependency is required by the integrated layout. The previous `react-router-dom` imports were removed because that package was not present in the existing `package.json`.
